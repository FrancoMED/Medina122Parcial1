
package GestorFestival;

import java.util.List;
import java.util.ArrayList;
import java.util.Objects;

public class Festival {
    
    private final String nombre;
    private final List<Actividad> actividades;
    
    
    public Festival(String nombre){
        Objects.requireNonNull(nombre, "El nombre del festival no puede ser nulo");
        this.nombre = nombre;
        this.actividades = new ArrayList<>();
        
        
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException {
        if (actividad == null) {
            throw new IllegalArgumentException("La actividad es obligatoria");
        }
        actividades.add(actividad);
    }
    
    public List<Actividad> obtenerActividades(){
        return new ArrayList<>(actividades);
    }
    
    public List<Actividad> filtrarPorFranja(FranjaHoraria franja) {
        List<Actividad> actividadesFiltradas = new ArrayList<>();
        for (Actividad actividad : actividades) {
            if(actividad.getFranja() == franja ) {
                actividadesFiltradas.add(actividad);
            }
        }
        return actividadesFiltradas;
    }
    
    public List<Actividad> obtenerActividadesDeDuracionMaxima(int limite){
        List<Actividad> encontradas = new ArrayList<>();
        for(Actividad actividad:  actividades) {
            if(actividad.tieneDuracionMaxima(limite)) {
                encontradas.add(actividad);
            }
            
        }
        return encontradas;
    }
    
}

