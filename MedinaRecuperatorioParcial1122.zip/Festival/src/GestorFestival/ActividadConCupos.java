
package GestorFestival;

public abstract class ActividadConCupos extends Actividad implements Reservable{
   
    private int cupos;
    
    public ActividadConCupos(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int cupos){
        super(codigo, titulo, franja, duracionBase);
        validarCantidad(cupos, "cupos");
        this.cupos = cupos;
    
    }
    
    public int getCupos(){
        return cupos;
    }
    
    public String reservarLugar() {
        if (cupos == 0) {
            throw new IllegalArgumentException("No hay mas lugares disponibles para " + getTitulo());
        }
        cupos--;
        return "Reserva confirmada para" + getTitulo() + ". Cupos restantes: " + cupos;
               
    }
    
    
    
}
