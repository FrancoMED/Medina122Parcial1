
package GestorFestival;

public enum FranjaHoraria {
       MATUTINA,
       VESPERTINA, 
       NOCTURNA
}
