
package GestorFestival;

public interface Presentable {
    void presentar();
}
