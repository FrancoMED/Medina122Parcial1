
package GestorFestival;

public class ActividadDuplicadaException extends RuntimeException{
    
    public ActividadDuplicadaException(String mensaje) {
        super(mensaje);
    }
}
