
package GestorFestival;

import java.util.Objects;


public abstract class Actividad {
    private final String codigo;
    private final String titulo;
    private final FranjaHoraria franja;
    private final int duracionBase;
    
    public Actividad(String codigo, String titulo, FranjaHoraria franja, int duracionBase){
        validarTexto(codigo, "codigo");
        validarTexto(titulo, "titulo");
        
        if(franja == null) {
            throw new IllegalArgumentException("La franja horaria es obligatoria");
        }
        
        validarPositivo(duracionBase, "duracion base");
        this.codigo = codigo;
        this.titulo = titulo;
        this.franja = franja;
        this.duracionBase = duracionBase;
    }
    
    public String getCodigo(){
        return codigo;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public FranjaHoraria getFranja(){
        return franja;
    }
    
    public int getDuracionBase(){
        return duracionBase;
    } 
    
    protected static void validarPositivo(int valor, String campo){
        if(valor <= 0){
            throw new IllegalArgumentException("el valor de " + campo + "debe ser mayor que 0");
        }
    }
    
    private static void validarTexto(String valor, String campo) {
        if(valor == null || valor.isBlank()){
            throw new IllegalArgumentException("el " + campo + "es obligatorio");
        }
    }
    
    protected static void validarCantidad(int valor, String campo){
        if(valor < 0){
            throw new IllegalArgumentException("el valor de " + campo + "debe ser mayor que 0");
        }
    }
    
    public abstract int calcularDuracionTotal();
    
    public boolean tieneDuracionMaxima(int limite) {
        return calcularDuracionTotal() <= limite;
    }
    
    @Override
    public boolean equals(Object o){
        boolean iguales = false;
        if(o instanceof Actividad) {
            Actividad act = (Actividad) o;
            iguales = Objects.equals(codigo, act.codigo) && Objects.equals(titulo, act.titulo);
        }
        return iguales;
    }
    
    @Override 
    public int hashCode() {
        return Objects.hash(codigo, titulo);
    }

    @Override
    public String toString() {
        return "codigo=" + codigo + ", titulo=" + titulo + ", franja=" + franja + ", duracionBase=" + duracionBase;
    }
    
    
}
