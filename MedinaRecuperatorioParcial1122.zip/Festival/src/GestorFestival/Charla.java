
package GestorFestival;


public class Charla extends ActividadConCupos implements Presentable{
    
    private final int minutosPreguntas;
    
    public Charla(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int minutosPreguntas, int cupos){
        
        super(codigo, titulo, franja, duracionBase, cupos);
        validarCantidad(minutosPreguntas, "minutos de practica");
        this.minutosPreguntas = minutosPreguntas;
    }
    
    public int getMinutosPreguntas(){
        return minutosPreguntas;
    }
    
    @Override
    public int calcularDuracionTotal(){
        return getDuracionBase() + minutosPreguntas;
    }
    
    @Override
    public void presentar(){
        System.out.println("Presentacion de charla: " + getTitulo());
    }
    
    @Override
    public String toString(){
        return "Charla" + super.toString() + ", minutosPreguntas= " + minutosPreguntas + ", cupos= " + getCupos();
    }
    
}