
package GestorFestival;

public class Taller extends ActividadConCupos{
    private final int minutosPractica;
    
    public Taller(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int minutosPractica, int cupos){
        
        super(codigo, titulo, franja, duracionBase, cupos);
        validarCantidad(minutosPractica, "minutos de practica");
        this.minutosPractica = minutosPractica;
        
        
    }
    
    public int minutosPractica(){
            return minutosPractica;
        }
    
    @Override
    public int calcularDuracionTotal(){
        return getDuracionBase() + minutosPractica;
    }
    
    @Override
    public String toString(){
        return "Taller" + super.toString() + ", minutosPractica= " + minutosPractica + ", cupos= " + getCupos();
    }
    
}
