
package GestorFestival;


public interface Reservable {
    
    String reservarLugar();
}
