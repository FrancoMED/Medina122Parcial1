
package GestorFestival;

public class MuestraInteractica extends Actividad implements Presentable{
    private static final int MINUTOSPORESTACION = 5;
    private final int estaciones;
    
    
    public MuestraInteractica(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int estaciones) {
        super(codigo, titulo, franja, duracionBase);
        
        validarPositivo(estaciones, "estaciones");
        this.estaciones = estaciones;  
                
    }
    
    public int getEstaciones(){
        return estaciones;
    }
    
    @Override
    public int calcularDuracionTotal(){
        return getDuracionBase() + MINUTOSPORESTACION * estaciones;
    }
    
    @Override
    public void presentar(){
        System.out.println("Presentacion de muestra: " + getTitulo());
    }
    
    @Override
    public String toString(){
        return "MuestraInteractiva " + super.toString() + ", estaciones= " + estaciones;
    }
    
    
}
