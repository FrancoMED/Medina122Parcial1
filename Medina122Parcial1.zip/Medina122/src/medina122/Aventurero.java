package medina122;

import java.util.Objects;

public abstract class Aventurero {
    
    private final String codigo;
    private final String nombre;
    private final Rango rango;
    
    public Aventurero(String codigo, String nombre, Rango rango) {
        validarTexto(codigo, "El codigo del aventurero es obligatorio");
        validarTexto(nombre, "El nombre del aventurero es obligatorio");
        if(rango == null) {
            throw new IllegalArgumentException("El rango del aventurero es obligatorio");
        }
        
        this.codigo = codigo;
        this.nombre = nombre;
        this.rango = rango;
    }
    
    protected static void validarTexto(String texto, String mensaje){
        if(texto == null || texto.isBlank()) {
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    protected static void validarPositivo(int valor, String poder){
        if (valor <= 0) {
            throw new IllegalArgumentException(poder + "debe ser mayor a cero");
        }
    }
   
    
    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Rango getRango() {
        return rango;
    }
    
    public abstract void atacar();
    
    public abstract int calcularPoder();
    
    @Override
    public boolean equals(Object o) {
        boolean iguales = false;
        if (o instanceof Aventurero) {
            Aventurero otro = (Aventurero) o;
            iguales = Objects.equals(codigo, otro.codigo)
                && Objects.equals(nombre, otro.nombre);
            }
        return iguales;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo, nombre);
    }
    
    @Override
    public String toString(){
        return "codigo=" + codigo + ", nombre=" + nombre + ", rango=" + rango; 
    }
    
}
