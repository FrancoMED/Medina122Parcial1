package medina122;

import java.util.ArrayList;
import java.util.List;

public class GremioAventureros {
    
    private final String nombre;
    private final List<Aventurero> aventureros;

    public GremioAventureros(String nombre) {
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre del gremio es obligatorio");
        }
        this.nombre = nombre;
        this.aventureros = new ArrayList<>();
    }
   
    public String getNombre() {
        return nombre;
    }
    
    public void agregarAventurero(Aventurero aventurero) throws AventureroDuplicadoException {
        if(nombre == null){
            throw new IllegalArgumentException("El aventurero es obligatorio");
        }
        if(aventureros.contains(aventurero)) {
            throw new AventureroDuplicadoException("Ya existe un aventurero con el codigo: " + aventurero.getCodigo() + 
                    " y el nombre: " + aventurero.getNombre());
        } 
        aventureros.add(aventurero);       
    }
    
    public List<Aventurero> obtenerAventureros() {
        return new ArrayList<>(aventureros);
    }    
    
    public List<Aventurero> filtrarPorRango(Rango rango) {
        if(rango == null){
            throw new IllegalArgumentException("El rango es obligatorio");
        }
        List<Aventurero> filtrados = new ArrayList<>();
        for (Aventurero aventurero : aventureros) {
            if (aventurero.getRango() == rango) {
                filtrados.add(aventurero);
            }
        }
        return filtrados;
    }
     
    public List<Aventurero> obtenerAventurerosPoderosos(int poderMinimo) {
        List<Aventurero> poderosos = new ArrayList<>();
        for (Aventurero aventurero : aventureros) {
            if (aventurero.calcularPoder() >= poderMinimo) {
                poderosos.add(aventurero);
            }
        }
        return poderosos;
    }
}
