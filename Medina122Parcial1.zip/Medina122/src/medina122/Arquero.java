package medina122;

public class Arquero extends Aventurero implements Entrenable{
    
    private final int precision;
    
    public Arquero(String codigo, String nombre, Rango rango, int precision) {
        super(codigo, nombre, rango);
        validarPositivo(precision, "La precision");
        this.precision = precision;
    }
    
    public int getPrecision() {
        return precision;
    }
    
    @Override
    public void atacar(){
        System.out.println("El arquero: " + getNombre() + " lanzo una flecha");
    }
    
    @Override
    public void entrenar(){
        System.out.println("El arquero: " + getNombre() + " esta practicando punteria");
    }
    
    @Override
    public int calcularPoder(){
        return precision * 3;
    }
    
    @Override
    public String toString() {
        return "Arquero [" + super.toString() + ", precision=" + precision + "]";
    }
    
}
