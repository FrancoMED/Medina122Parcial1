package medina122;


public class Mago extends Aventurero{
    private final int mana;
    
    public Mago(String codigo, String nombre, Rango rango, int mana) {
        super(codigo, nombre, rango);
        this.mana = mana;
    }
    
    public int getMana() {
        return mana;
    }
    
    @Override
    public void atacar(){
        System.out.println("El mago: " + getNombre() + " lanzo un hechizo");
    }
    
    @Override
    public int calcularPoder(){
        return mana + 10;
    }
    
    @Override
    public String toString() {
        return "Mago [" + super.toString() + ", mana=" + mana + "]";
    }
    
}
