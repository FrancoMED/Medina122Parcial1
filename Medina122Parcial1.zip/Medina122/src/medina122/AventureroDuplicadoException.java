package medina122;


public class AventureroDuplicadoException extends RuntimeException {
            
    public AventureroDuplicadoException(String mensaje) {
        super(mensaje);
    }
    
}
