package medina122;

public interface Entrenable {

    abstract void entrenar();
}
