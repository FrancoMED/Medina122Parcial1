package medina122;


public class Guerrero extends Aventurero implements Entrenable{
    private final int fuerza;

    public Guerrero(String codigo, String nombre, Rango rango, int fuerza) {
        super(codigo, nombre, rango);
        validarPositivo(fuerza, "La fuerza");
        this.fuerza = fuerza;
    }

    public int getFuerza() {
        return fuerza;
    }
    
    @Override
    public void atacar(){
        System.out.println("El guerrero: " + getNombre() + " ataco con su espada");
    }
    
    @Override
    public void entrenar(){
        System.out.println("El guerrero: " + getNombre() + " esta entrenando con su espada");
    }
    
    @Override
    public int calcularPoder(){
        return fuerza * 2;
    }
    
    @Override
    public String toString() {
        return "Guerrero [" + super.toString() + ", fuerza=" + fuerza + "]";
    }
    
}
