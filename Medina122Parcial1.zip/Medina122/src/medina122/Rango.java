package medina122;

public enum Rango{
    BRONCE,
    PLATA,
    ORO;
}
